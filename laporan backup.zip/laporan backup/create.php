<?php
require "koneksi.php";

if (isset($_POST['Tambah'])) {
	$val_nama = $_POST['input_nama'];
	$val_kelas = $_POST['input_kelas'];

	$sql = "INSERT INTO  table_curd (nama, Kelas) VALUES ('$val_nama','$val_kelas')";
	$execute = mysqli_query($koneksi, $sql);

	if ($execute) {
		header('Location:read.php');
	} else {
		echo "GAGAL CREATE DATA !";
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>CREATE PHP</title>
</head>
<body>
	<form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
		<hr>

		<h3>Tambah/Create data</h3>
		<label>Nama</label>
		<input type="text" name="input_nama">

		<br>
		<br>

		<label>Kelas</label>
		<input type="text" name="input_kelas">

		<br>
		<br>	

		<input type="submit" name="Tambah" value="Tambah">
		</form>

</body>
</html>