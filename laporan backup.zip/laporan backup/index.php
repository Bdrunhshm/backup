<?php
require ("koneksi.php");

$result = mysqli_query ($mysqli, "SELECT * FROM ")
?>


<!DOCTYPE html>
<html>
<head>ooo
	<title></title>
</head>
<body>

</html>