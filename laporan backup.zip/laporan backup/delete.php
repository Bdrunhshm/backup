<?php
require "koneksi.php";

$id  = $_GET['id'];
$sql = "DELETE FROM table_crud WHERE id='$id'";
$execute = mysqli_query($koneksi,$sql);

if (execute) {
	header("Location:read.php");
} else {
	echo "GAGAL MENGHAPUS !";
}


?>