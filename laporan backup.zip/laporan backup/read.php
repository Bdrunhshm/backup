<?php
require "koneksi.php";
$sql	 = "SELECT * FROM table_crud";
$execute = mysqli_query($koneksi,$sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Read PHP</title>
</head>
<body>
	<a href="create.php">Tambah data</a>
	<table  border="1" width="50%">
		<thead>
			<th>Id</th>
			<th>Nama</th>
			<th>Kelas</th>
			<th>Aksi</th>
		</thead>
		<?php while($result  = mysqli_fetch_assoc($execute)){ ?>
		<tr>
			<td><?= $result['id']?></td>
			<td><?= $result['nama']?></td>
			<td><?= $result['kelas']?></td>
			<td><a href="update.php?id=<?= $result['id']?>">Update</a> 
				| 
				<a href="delete.php?id=<?= $result['id']?>">Delete</a></td> 
		</tr>
	<?php }?>
	</table>

</body>
</html>